package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val algorithmId: String,
    val createdAt: Long = System.currentTimeMillis()
)

data class AlgorithmWithBookmark(
    @Embedded val algorithm: AlgorithmEntity,
    val isBookmarked: Boolean
)

@Dao
interface AlgorithmDao {
    @Query("""
        SELECT a.*, (b.algorithmId IS NOT NULL) AS isBookmarked 
        FROM algorithms a 
        LEFT JOIN bookmarks b ON a.id = b.algorithmId
        ORDER BY a.name ASC
    """)
    fun getAllAlgorithms(): Flow<List<AlgorithmWithBookmark>>

    @Query("""
        SELECT a.*, (b.algorithmId IS NOT NULL) AS isBookmarked 
        FROM algorithms a 
        INNER JOIN bookmarks b ON a.id = b.algorithmId
        ORDER BY b.createdAt DESC
    """)
    fun getBookmarkedAlgorithms(): Flow<List<AlgorithmWithBookmark>>

    @Query("SELECT * FROM algorithms WHERE id = :id LIMIT 1")
    suspend fun getAlgorithmById(id: String): AlgorithmEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlgorithms(algorithms: List<AlgorithmEntity>)

    @Query("DELETE FROM algorithms")
    suspend fun clearAlgorithms()

    // Bookmarks
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addBookmark(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE algorithmId = :algorithmId")
    suspend fun removeBookmark(algorithmId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE algorithmId = :id)")
    suspend fun isBookmarked(id: String): Boolean

    // Details/Cache
    @Query("SELECT * FROM algorithm_details WHERE id = :id LIMIT 1")
    suspend fun getAlgorithmDetails(id: String): AlgorithmDetailEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlgorithmDetails(details: AlgorithmDetailEntity)

    @Query("DELETE FROM algorithm_details WHERE id = :id")
    suspend fun clearDetailsById(id: String)

    @Query("DELETE FROM algorithm_details")
    suspend fun clearAllDetails()
    
    @Query("SELECT COUNT(*) FROM algorithm_details")
    suspend fun getCachedCount(): Int
}
