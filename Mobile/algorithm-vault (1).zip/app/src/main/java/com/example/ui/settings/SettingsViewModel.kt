package com.example.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AlgorithmRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(private val repository: AlgorithmRepository) : ViewModel() {

    private val _username = MutableStateFlow(repository.githubUsername)
    val username: StateFlow<String> = _username.asStateFlow()

    private val _repo = MutableStateFlow(repository.githubRepo)
    val repo: StateFlow<String> = _repo.asStateFlow()

    private val _branch = MutableStateFlow(repository.githubBranch)
    val branch: StateFlow<String> = _branch.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    fun updateUsername(value: String) {
        _username.value = value
    }

    fun updateRepo(value: String) {
        _repo.value = value
    }

    fun updateBranch(value: String) {
        _branch.value = value
    }

    fun saveConfiguration() {
        viewModelScope.launch {
            if (_username.value.isBlank() || _repo.value.isBlank() || _branch.value.isBlank()) {
                _toastEvent.emit("Fields cannot be empty!")
                return@launch
            }
            repository.updateConfig(_username.value, _repo.value, _branch.value)
            _toastEvent.emit("Configuration saved successfully!")
        }
    }

    fun restoreDefaults() {
        viewModelScope.launch {
            _username.value = "sakib-12345"
            _repo.value = "AlgorithmVault"
            _branch.value = "main"
            repository.updateConfig("sakib-12345", "AlgorithmVault", "main")
            _toastEvent.emit("Restored default Repository configurations!")
        }
    }

    class Factory(private val repository: AlgorithmRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(repository) as T
        }
    }
}
