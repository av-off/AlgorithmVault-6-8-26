package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class AlgorithmDto(
    @Json(name = "id") val id: String,
    @Json(name = "name") val name: String,
    @Json(name = "videoId") val videoId: String?,
    @Json(name = "hint") val hint: String,
    @Json(name = "difficulty") val difficulty: String, // "easy", "medium", "hard"
    @Json(name = "time") val time: String,
    @Json(name = "space") val space: String,
    @Json(name = "tags") val tags: List<String>,
    @Json(name = "files") val files: Map<String, String>?
)
