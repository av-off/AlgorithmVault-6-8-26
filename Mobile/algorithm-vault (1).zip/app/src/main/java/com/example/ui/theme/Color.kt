package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors (Modern Cozy Light)
val TealPrimaryLight = Color(0xFF00796B)
val TealSecondaryLight = Color(0xFF004D40)
val TealTertiaryLight = Color(0xFF00B0FF)
val BackgroundLight = Color(0xFFF6F8FA) // GitHub Light Background
val SurfaceLight = Color(0xFFFFFFFF)
val OnPrimaryLight = Color(0xFFFFFFFF)
val OnBackgroundLight = Color(0xFF24292E)
val OnSurfaceLight = Color(0xFF24292E)

// Dark Colors (GitHub Cosmic Slate)
val TealPrimaryDark = Color(0xFF00E5C3) // Electric Teal Accent
val PurpleAccentDark = Color(0xFF9E77ED) // Cosmic Purple secondary
val BackgroundDark = Color(0xFF0D1117) // GitHub deep dark
val SurfaceDark = Color(0xFF161B22) // GitHub surface
val SurfaceVariantDark = Color(0xFF21262D) // GitHub secondary surface
val OnPrimaryDark = Color(0xFF0D1117) // Slate black
val OnBackgroundDark = Color(0xFFF0F6FC) // Off-white
val OnSurfaceDark = Color(0xFFC9D1D9) // Light grey
val BorderDark = Color(0xFF30363D) // GitHub border line

// Difficulty Colors
val DifficultyEasy = Color(0xFF00E676)
val DifficultyMedium = Color(0xFFFF9800)
val DifficultyHard = Color(0xFFFF5252)
