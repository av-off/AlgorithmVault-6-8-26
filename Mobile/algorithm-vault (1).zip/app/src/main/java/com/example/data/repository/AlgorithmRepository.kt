package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.*
import com.example.data.remote.GitHubApiService
import com.example.data.remote.AlgorithmDto
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class AlgorithmRepository(
    private val context: Context,
    private val dao: AlgorithmDao
) {
    // Dynamic settings
    var githubUsername: String = "sakib-12345"
        private set
    var githubRepo: String = "AlgorithmVault"
        private set
    var githubBranch: String = "main"
        private set

    init {
        // Load configurations if any saved (simplified inline local preferences)
        val prefs = context.getSharedPreferences("algorithm_vault_prefs", Context.MODE_PRIVATE)
        githubUsername = prefs.getString("username", "sakib-12345") ?: "sakib-12345"
        githubRepo = prefs.getString("repo", "AlgorithmVault") ?: "AlgorithmVault"
        githubBranch = prefs.getString("branch", "main") ?: "main"

        if (githubRepo == "Algorithm-Vault") {
            githubRepo = "AlgorithmVault"
            prefs.edit().putString("repo", "AlgorithmVault").apply()
        }
    }

    fun updateConfig(username: String, repo: String, branch: String) {
        githubUsername = username.trim()
        githubRepo = repo.trim()
        githubBranch = branch.trim()

        context.getSharedPreferences("algorithm_vault_prefs", Context.MODE_PRIVATE).edit()
            .putString("username", githubUsername)
            .putString("repo", githubRepo)
            .putString("branch", githubBranch)
            .apply()
    }

    private val moshi = Moshi.Builder().build()
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    // Base client
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://raw.githubusercontent.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val apiService = retrofit.create(GitHubApiService::class.java)

    // Flow endpoints for reactive UI
    val allAlgorithms: Flow<List<AlgorithmWithBookmark>> = dao.getAllAlgorithms()
    val bookmarkedAlgorithms: Flow<List<AlgorithmWithBookmark>> = dao.getBookmarkedAlgorithms()

    /**
     * Seeds initial algorithms into Room the first time the app is launched.
     */
    suspend fun seedInitialDataIfNeeded() {
        withContext(Dispatchers.IO) {
            val count = dao.getCachedCount()
            if (count == 0) {
                Log.d("AlgorithmRepository", "Seeding initial default algorithms for offline use.")
                
                val seedList = getMockAlgorithms()
                dao.insertAlgorithms(seedList.map { it.first })
                
                seedList.forEach { (_, detail) ->
                    dao.insertAlgorithmDetails(detail)
                }

                // Add a few bookmarks by default to show how the UI works
                dao.addBookmark(BookmarkEntity("binary-search"))
            }
        }
    }

    /**
     * Pulls algorithms.json from GitHub and updates local algorithms metadata.
     */
    suspend fun syncAlgorithms(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val url = "https://raw.githubusercontent.com/$githubUsername/$githubRepo/$githubBranch/algorithms.json"
            Log.d("AlgorithmRepository", "Syncing from Github: $url")
            
            val responseBody = apiService.getRawFile(url)
            val jsonString = responseBody.string()
            
            val listType = Types.newParameterizedType(List::class.java, AlgorithmDto::class.java)
            val adapter = moshi.adapter<List<AlgorithmDto>>(listType)
            val dtoList = adapter.fromJson(jsonString) ?: emptyList()

            if (dtoList.isNotEmpty()) {
                val entities = dtoList.map { dto ->
                     AlgorithmEntity(
                         id = dto.id,
                         name = dto.name,
                         videoId = dto.videoId,
                         hint = dto.hint,
                         difficulty = dto.difficulty,
                         timeComplexity = dto.time,
                         spaceComplexity = dto.space,
                         tags = dto.tags.joinToString(","),
                         pythonPath = dto.files?.get("python") ?: dto.files?.get("py") ?: dto.files?.get("python3"),
                         cppPath = dto.files?.get("cpp") ?: dto.files?.get("c++") ?: dto.files?.get("cppPath"),
                         javaPath = dto.files?.get("java") ?: dto.files?.get("javaPath")
                     )
                }
                
                // Keep database clean and dynamic
                dao.clearAlgorithms()
                dao.insertAlgorithms(entities)
                Result.success(Unit)
            } else {
                Result.failure(Exception("Downloaded algorithms list was empty"))
            }
        } catch (e: Exception) {
            Log.e("AlgorithmRepository", "Failed to sync remote repo metadata", e)
            Result.failure(e)
        }
    }

    /**
     * Returns full Markdown docs and source files. Fetches from cache if available;
     * otherwise, fetches from Github dynamically and caches them.
     */
    suspend fun getOrFetchDetails(id: String, forceRefresh: Boolean = false): Result<AlgorithmDetailEntity> = withContext(Dispatchers.IO) {
        try {
            val cached = dao.getAlgorithmDetails(id)
            if (cached != null && !forceRefresh) {
                return@withContext Result.success(cached)
            }

            // Fetch metadata
            val algo = dao.getAlgorithmById(id) ?: return@withContext Result.failure(Exception("Algorithm not found locally"))

            // Extracted prefixes for convention-based fallback paths
            val prefix = id.split("-").firstOrNull() ?: id

            // Download README.md
            val readmePaths = listOf(
                "algorithms/$id/README.md",
                "algorithms/$id/readme.md"
            )
            val readmeContent = tryFetchFromUrls(readmePaths) ?: "# ${algo.name}\n\nCould not fetch remote README.md. Please check your network connection."

            // Download Python
            val pythonPaths = buildList {
                if (!algo.pythonPath.isNullOrEmpty()) add(algo.pythonPath)
                add("algorithms/$id/$prefix.py")
                add("algorithms/$id/$id.py")
            }.distinct()
            val pythonCode = tryFetchFromUrls(pythonPaths) ?: "# Python source file not uploaded yet or failed to download"

            // Download C++
            val cppPaths = buildList {
                if (!algo.cppPath.isNullOrEmpty()) add(algo.cppPath)
                add("algorithms/$id/$prefix.cpp")
                add("algorithms/$id/$id.cpp")
            }.distinct()
            val cppCode = tryFetchFromUrls(cppPaths) ?: "// C++ source file not uploaded yet or failed to download"

            // Download Java
            val javaPaths = buildList {
                if (!algo.javaPath.isNullOrEmpty()) add(algo.javaPath)
                add("algorithms/$id/$prefix.java")
                add("algorithms/$id/$id.java")
            }.distinct()
            val javaCode = tryFetchFromUrls(javaPaths) ?: "// Java source file not uploaded yet or failed to download"

            val details = AlgorithmDetailEntity(
                id = id,
                readmeContent = readmeContent,
                pythonCode = pythonCode,
                cppCode = cppCode,
                javaCode = javaCode,
                lastDownloaded = System.currentTimeMillis()
            )

            dao.insertAlgorithmDetails(details)
            Result.success(details)
        } catch (e: Exception) {
            Log.e("AlgorithmRepository", "Failed to fetch algorithm details", e)
            Result.failure(e)
        }
    }

    // Bookmark Toggle Management
    suspend fun toggleBookmark(id: String) {
        withContext(Dispatchers.IO) {
            if (dao.isBookmarked(id)) {
                dao.removeBookmark(id)
            } else {
                dao.addBookmark(BookmarkEntity(id))
            }
        }
    }

    // Cache management actions
    suspend fun getCachedCount(): Int = withContext(Dispatchers.IO) {
         dao.getCachedCount()
    }

    suspend fun clearCache() {
        withContext(Dispatchers.IO) {
            dao.clearAllDetails()
        }
    }

    private suspend fun tryFetchFromUrls(paths: List<String>): String? {
        for (path in paths) {
            val url = "https://raw.githubusercontent.com/$githubUsername/$githubRepo/$githubBranch/$path"
            try {
                val content = apiService.getRawFile(url).string()
                if (content.isNotEmpty()) {
                    return content
                }
            } catch (e: Exception) {
                Log.d("AlgorithmRepository", "Failed to fetch from: $url, trying fallback.")
            }
        }
        return null
    }

    /**
     * Seeds fallback offline structures to avoid showing blank states before the first dynamic sync.
     */
    private fun getMockAlgorithms(): List<Pair<AlgorithmEntity, AlgorithmDetailEntity>> {
        return listOf(
            Pair(
                AlgorithmEntity(
                    id = "binary-search",
                    name = "Binary Search",
                    videoId = "fp_-G4ILlBw",
                    hint = "Efficient O(log n) searching in sorted arrays",
                    difficulty = "easy",
                    timeComplexity = "O(log n)",
                    spaceComplexity = "O(1)",
                    tags = "search,divide-conquer",
                    pythonPath = "algorithms/binary-search/binary.py",
                    cppPath = "algorithms/binary-search/binary.cpp",
                    javaPath = "algorithms/binary-search/binary.java"
                ),
                AlgorithmDetailEntity(
                    id = "binary-search",
                    readmeContent = """
                        # Binary Search
                        
                        Binary Search is a divide-and-conquer algorithm that finds the position of a target value within a **sorted array**.
                        
                        ## How it works
                        
                        1. Start with the middle element.
                        2. If target == middle, found!
                        3. If target < middle, search left half.
                        4. If target > middle, search right half.
                        5. Repeat until found or range is empty.
                        
                        ## Complexity
                        
                        - **Time Complexity:** O(log n)
                        - **Space Complexity:** O(1) iterative
                    """.trimIndent(),
                    pythonCode = """
                        def binary_search(arr, target):
                            left, right = 0, len(arr) - 1
                            while left <= right:
                                mid = (left + right) // 2
                                if arr[mid] == target:
                                    return mid
                                elif arr[mid] < target:
                                    left = mid + 1
                                else:
                                    right = mid - 1
                            return -1
                        
                        arr = [1, 3, 5, 7, 9, 11, 13]
                        print(binary_search(arr, 7))  # Output: 3
                    """.trimIndent(),
                    cppCode = """
                        #include <iostream>
                        #include <vector>
                        using namespace std;
                        
                        int binarySearch(vector<int>& arr, int target) {
                            int left = 0, right = arr.size() - 1;
                            while (left <= right) {
                                int mid = left + (right - left) / 2;
                                if (arr[mid] == target) return mid;
                                else if (arr[mid] < target) left = mid + 1;
                                else right = mid - 1;
                            }
                            return -1;
                        }
                    """.trimIndent(),
                    javaCode = """
                        public class BinarySearch {
                            public static int binarySearch(int[] arr, int target) {
                                int left = 0, right = arr.length - 1;
                                while (left <= right) {
                                    int mid = left + (right - left) / 2;
                                    if (arr[mid] == target) return mid;
                                    else if (arr[mid] < target) left = mid + 1;
                                    else right = mid - 1;
                                }
                                return -1;
                            }
                        }
                    """.trimIndent()
                )
            ),
            Pair(
                AlgorithmEntity(
                    id = "bubble-sort",
                    name = "Bubble Sort",
                    videoId = null,
                    hint = "Simple comparison-based sorting algorithm",
                    difficulty = "easy",
                    timeComplexity = "O(n²)",
                    spaceComplexity = "O(1)",
                    tags = "sort",
                    pythonPath = "algorithms/bubble-sort/bubble.py",
                    cppPath = "algorithms/bubble-sort/bubble.cpp",
                    javaPath = null
                ),
                AlgorithmDetailEntity(
                    id = "bubble-sort",
                    readmeContent = """
                        # Bubble Sort
                        
                        Bubble Sort repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order.
                        
                        ## How it works
                        
                        1. Compare adjacent elements.
                        2. Swap if out of order.
                        3. Repeat until no swaps are needed.
                    """.trimIndent(),
                    pythonCode = """
                        def bubble_sort(arr):
                            n = len(arr)
                            for i in range(n):
                                swapped = False
                                for j in range(0, n - i - 1):
                                    if arr[j] > arr[j + 1]:
                                        arr[j], arr[j + 1] = arr[j + 1], arr[j]
                                        swapped = True
                                if not swapped:
                                    break
                            return arr
                        
                        print(bubble_sort([64, 34, 25, 12, 22, 11, 90]))
                    """.trimIndent(),
                    cppCode = """
                        #include <iostream>
                        #include <vector>
                        using namespace std;
                        
                        void bubbleSort(vector<int>& arr) {
                            int n = arr.size();
                            for (int i = 0; i < n - 1; i++) {
                                bool swapped = false;
                                for (int j = 0; j < n - i - 1; j++) {
                                    if (arr[j] > arr[j + 1]) {
                                        swap(arr[j], arr[j + 1]);
                                        swapped = true;
                                    }
                                }
                                if (!swapped) break;
                            }
                        }
                    """.trimIndent(),
                    javaCode = null
                )
            ),
            Pair(
                AlgorithmEntity(
                    id = "quick-sort",
                    name = "Quick Sort",
                    videoId = null,
                    hint = "Fast divide-and-conquer sorting with pivot",
                    difficulty = "hard",
                    timeComplexity = "O(n log n)",
                    spaceComplexity = "O(log n)",
                    tags = "sort,divide-conquer",
                    pythonPath = "algorithms/quick-sort/quick.py",
                    cppPath = null,
                    javaPath = null
                ),
                AlgorithmDetailEntity(
                    id = "quick-sort",
                    readmeContent = """
                        # Quick Sort
                        
                        Quick Sort is an efficient, in-place sorting algorithm that uses a pivot to partition the array.
                    """.trimIndent(),
                    pythonCode = """
                        def quick_sort(arr):
                            if len(arr) <= 1:
                                return arr
                            pivot = arr[len(arr) // 2]
                            left   = [x for x in arr if x < pivot]
                            middle = [x for x in arr if x == pivot]
                            right  = [x for x in arr if x > pivot]
                            return quick_sort(left) + middle + quick_sort(right)
                    """.trimIndent(),
                    cppCode = null,
                    javaCode = null
                )
            )
        )
    }
}
