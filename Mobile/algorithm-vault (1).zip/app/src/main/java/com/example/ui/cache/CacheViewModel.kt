package com.example.ui.cache

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AlgorithmRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CacheViewModel(private val repository: AlgorithmRepository) : ViewModel() {

    private val _cachedFilesCount = MutableStateFlow(0)
    val cachedFilesCount: StateFlow<Int> = _cachedFilesCount.asStateFlow()

    private val _eventMessage = MutableSharedFlow<String>()
    val eventMessage: SharedFlow<String> = _eventMessage.asSharedFlow()

    init {
        loadMetrics()
    }

    fun loadMetrics() {
        viewModelScope.launch {
            _cachedFilesCount.value = repository.getCachedCount()
        }
    }

    fun clearLocalCache() {
        viewModelScope.launch {
            repository.clearCache()
            loadMetrics()
            _eventMessage.emit("Local algorithm codes and README cache cleared successfully!")
        }
    }

    fun recalculateOrSeed() {
        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
            loadMetrics()
            _eventMessage.emit("Re-seeded fallback database cache metrics!")
        }
    }

    class Factory(private val repository: AlgorithmRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return CacheViewModel(repository) as T
        }
    }
}
