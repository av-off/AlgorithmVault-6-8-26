package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AlgorithmWithBookmark
import com.example.data.repository.AlgorithmRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class HomeViewModel(private val repository: AlgorithmRepository) : ViewModel() {

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedDifficulty = MutableStateFlow<String?>(null)
    val selectedDifficulty: StateFlow<String?> = _selectedDifficulty.asStateFlow()

    private val _selectedTag = MutableStateFlow<String?>(null)
    val selectedTag: StateFlow<String?> = _selectedTag.asStateFlow()

    private val _syncMessage = MutableSharedFlow<String>()
    val syncMessage: SharedFlow<String> = _syncMessage.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
        }
    }

    // Reactive computation of filtered list
    val filteredAlgorithms: StateFlow<List<AlgorithmWithBookmark>> = combine(
        repository.allAlgorithms,
        _searchQuery,
        _selectedDifficulty,
        _selectedTag
    ) { list, query, difficulty, tag ->
        list.filter { item ->
            val matchQuery = query.isEmpty() || 
                    item.algorithm.name.contains(query, ignoreCase = true) ||
                    item.algorithm.hint.contains(query, ignoreCase = true) ||
                    item.algorithm.tags.contains(query, ignoreCase = true)

            val matchDiff = difficulty == null || 
                    item.algorithm.difficulty.equals(difficulty, ignoreCase = true)

            val matchTag = tag == null || 
                    item.algorithm.tags.split(",").any { it.trim().equals(tag, ignoreCase = true) }

            matchQuery && matchDiff && matchTag
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Dynamic collection of tags present across current database to display in filter chips
    val allAvailableTags: StateFlow<List<String>> = repository.allAlgorithms
        .map { list ->
            list.flatMap { 
                it.algorithm.tags.split(",").map { t -> t.trim() } 
            }.filter { it.isNotEmpty() }.distinct().sorted()
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun selectDifficulty(difficulty: String?) {
        _selectedDifficulty.value = difficulty
    }

    fun selectTag(tag: String?) {
        _selectedTag.value = tag
    }

    fun toggleBookmark(id: String) {
        viewModelScope.launch {
            repository.toggleBookmark(id)
        }
    }

    fun syncFromGitHub() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val result = repository.syncAlgorithms()
            _isRefreshing.value = false
            if (result.isSuccess) {
                _syncMessage.emit("Sync successful! Algorithms updated.")
            } else {
                _syncMessage.emit("Sync failed: " + (result.exceptionOrNull()?.message ?: "Check internet/repo configs."))
            }
        }
    }

    class Factory(private val repository: AlgorithmRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(repository) as T
        }
    }
}
