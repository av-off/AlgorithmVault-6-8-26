package com.example

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.repository.AlgorithmRepository

object ServiceLocator {
    private var database: AppDatabase? = null
    private var repo: AlgorithmRepository? = null

    fun initialize(context: Context) {
        if (database == null) {
            val db = AppDatabase.getDatabase(context)
            database = db
            repo = AlgorithmRepository(context.applicationContext, db.algorithmDao())
        }
    }

    fun getRepository(): AlgorithmRepository {
         return repo ?: throw IllegalStateException("ServiceLocator is not initialized yet. Call initialize(context) first.")
    }
}
