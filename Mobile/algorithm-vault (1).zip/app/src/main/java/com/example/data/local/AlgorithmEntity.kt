package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "algorithms")
data class AlgorithmEntity(
    @PrimaryKey val id: String,
    val name: String,
    val videoId: String?,
    val hint: String,
    val difficulty: String, // "easy", "medium", "hard"
    val timeComplexity: String,
    val spaceComplexity: String,
    val tags: String, // Comma-separated values
    val pythonPath: String?,
    val cppPath: String?,
    val javaPath: String?
)

@Entity(tableName = "algorithm_details")
data class AlgorithmDetailEntity(
    @PrimaryKey val id: String,
    val readmeContent: String?,
    val pythonCode: String?,
    val cppCode: String?,
    val javaCode: String?,
    val lastDownloaded: Long = System.currentTimeMillis()
)
