package com.example.data.remote

import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Url

interface GitHubApiService {
    @GET("algorithms.json")
    suspend fun getAlgorithmsList(): List<AlgorithmDto>

    @GET
    suspend fun getRawFile(@Url url: String): ResponseBody
}
