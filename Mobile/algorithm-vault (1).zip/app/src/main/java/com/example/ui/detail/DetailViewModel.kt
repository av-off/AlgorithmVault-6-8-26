package com.example.ui.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AlgorithmDetailEntity
import com.example.data.local.AlgorithmEntity
import com.example.data.repository.AlgorithmRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface DetailUiState {
    object Loading : DetailUiState
    data class Success(
        val algorithm: AlgorithmEntity,
        val details: AlgorithmDetailEntity,
        val isBookmarked: Boolean
    ) : DetailUiState
    data class Error(val message: String) : DetailUiState
}

class DetailViewModel(
    private val repository: AlgorithmRepository,
    private val algorithmId: String
) : ViewModel() {

    private val _uiState = MutableStateFlow<DetailUiState>(DetailUiState.Loading)
    val uiState: StateFlow<DetailUiState> = _uiState.asStateFlow()

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing.asStateFlow()

    // Monitor bookmarked flow dynamically to keep favorite actions reactive instantly on Details screen
    val isBookmarked: Flow<Boolean> = repository.bookmarkedAlgorithms
        .map { list -> list.any { it.algorithm.id == algorithmId } }

    init {
        loadDetails()
    }

    fun loadDetails(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            if (forceRefresh) _refreshing.value = true else _uiState.value = DetailUiState.Loading
            
            // Get current synced properties of the algorithm from local list
            val localAlgoList = repository.allAlgorithms.firstOrNull() ?: emptyList()
            val algorithm = localAlgoList.find { it.algorithm.id == algorithmId }

            if (algorithm == null) {
                _uiState.value = DetailUiState.Error("Algorithm not found locally. Please perform a Sync on Home screen.")
                _refreshing.value = false
                return@launch
            }

            // Sync/Fetch detailed markdown documentation and codes
            val detailResult = repository.getOrFetchDetails(algorithmId, forceRefresh)
            _refreshing.value = false

            if (detailResult.isSuccess) {
                _uiState.value = DetailUiState.Success(
                    algorithm = algorithm.algorithm,
                    details = detailResult.getOrThrow(),
                    isBookmarked = algorithm.isBookmarked
                )
            } else {
                _uiState.value = DetailUiState.Error(
                    detailResult.exceptionOrNull()?.message ?: "Unknown error while downloading files."
                )
            }
        }
    }

    fun toggleBookmark() {
        viewModelScope.launch {
            repository.toggleBookmark(algorithmId)
            // Re-update successfully loaded state with correct bookmarked properties
            val currentState = _uiState.value
            if (currentState is DetailUiState.Success) {
                _uiState.value = currentState.copy(isBookmarked = !currentState.isBookmarked)
            }
        }
    }

    class Factory(
        private val repository: AlgorithmRepository,
        private val algorithmId: String
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DetailViewModel(repository, algorithmId) as T
        }
    }
}
