package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.cache.CacheScreen
import com.example.ui.cache.CacheViewModel
import com.example.ui.detail.DetailScreen
import com.example.ui.detail.DetailViewModel
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize local database and repo instance
        ServiceLocator.initialize(this)
        
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                MainAppLayout()
            }
        }
    }
}

sealed class BottomTab(
    val route: String,
    val title: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val testTag: String
) {
    object Home : BottomTab("home_tab", "Home", Icons.Filled.Home, Icons.Outlined.Home, "tab_home")
    object Bookmarks : BottomTab("bookmarks_tab", "Saved", Icons.Filled.Bookmark, Icons.Outlined.BookmarkBorder, "tab_bookmarks")
    object Cache : BottomTab("cache_tab", "Storage", Icons.Filled.Storage, Icons.Outlined.Storage, "tab_cache")
    object Settings : BottomTab("settings_tab", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "tab_settings")
}

@Composable
fun MainAppLayout() {
    val navController = rememberNavController()
    val repository = ServiceLocator.getRepository()
    
    // ViewModels scoped appropriately
    val homeViewModel: HomeViewModel = viewModel(factory = HomeViewModel.Factory(repository))
    val settingsViewModel: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory(repository))
    val cacheViewModel: CacheViewModel = viewModel(factory = CacheViewModel.Factory(repository))

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route

            // Hide bottom navigation when showing algorithm details screen
            if (currentRoute != "detail_route/{id}") {
                NavigationBar(
                    modifier = Modifier
                        .navigationBarsPadding() // Protects gesture controls on Android
                        .testTag("bottom_nav_bar")
                ) {
                    val tabs = listOf(
                        BottomTab.Home,
                        BottomTab.Bookmarks,
                        BottomTab.Cache,
                        BottomTab.Settings
                    )
                    
                    tabs.forEach { tab ->
                        val isSelected = currentRoute == tab.route || 
                                (tab == BottomTab.Home && currentRoute == "home_tab")
                        
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != tab.route) {
                                    navController.navigate(tab.route) {
                                        // Pop up to the start destination of the graph to
                                        // avoid building up a large stack of destinations
                                        popUpTo(navController.graph.startDestinationId) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.title
                                )
                            },
                            label = { Text(tab.title) },
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = BottomTab.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // Home Screen Tab
            composable(BottomTab.Home.route) {
                HomeScreen(
                    viewModel = homeViewModel,
                    onAlgorithmClick = { id ->
                        navController.navigate("detail_route/$id")
                    }
                )
            }

            // Saved/Bookmarks Screen Tab (Using HomeScreen but displaying bookmarked items)
            composable(BottomTab.Bookmarks.route) {
                // Customized view of identical cards displaying ONLY favorites
                val filteredAlgorithms by homeViewModel.filteredAlgorithms.collectAsStateWithLifecycle()
                val bookmarkedAlgos = filteredAlgorithms.filter { it.isBookmarked }
                
                Box(
                    modifier = Modifier.fillMaxSize()
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        com.example.ui.home.HomeHeader(
                            onSyncClick = { homeViewModel.syncFromGitHub() },
                            isRefreshing = false
                        )
                        
                        Text(
                            text = "Bookmarks & Favorites",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp)
                        )

                        if (bookmarkedAlgos.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Outlined.BookmarkBorder,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                                        modifier = Modifier.size(64.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "No saved bookmarks yet",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    Text(
                                        text = "Bookmark items on the home screen to access them offline.",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                        modifier = Modifier.padding(horizontal = 16.dp)
                                    )
                                }
                            }
                        } else {
                            com.example.ui.home.AlgorithmsList(
                                algorithms = bookmarkedAlgos,
                                onItemClick = { id ->
                                    navController.navigate("detail_route/$id")
                                },
                                onBookmarkToggle = { homeViewModel.toggleBookmark(it) }
                            )
                        }
                    }
                }
            }

            // Storage/Cache Manager Screen Tab
            composable(BottomTab.Cache.route) {
                CacheScreen(viewModel = cacheViewModel)
            }

            // Settings Coordinates Screen Tab
            composable(BottomTab.Settings.route) {
                SettingsScreen(viewModel = settingsViewModel)
            }

            // Core Algorithm Detail Screen ROUTE
            composable(
                route = "detail_route/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { backStackEntry ->
                val algoId = backStackEntry.arguments?.getString("id") ?: ""
                val detailViewModel: DetailViewModel = viewModel(
                    factory = DetailViewModel.Factory(repository, algoId)
                )
                DetailScreen(
                    viewModel = detailViewModel,
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}
