# 📱 Algorithm Vault - Android App

[![Release](https://img.shields.io/badge/Release-APK-brightgreen.svg)](AlgorithmVault.apk)
[![Platform](https://img.shields.io/badge/Platform-Android-blue.svg)](https://developer.android.com)
[![Kotlin](https://img.shields.io/badge/Kotlin-2.0-purple.svg)](https://kotlinlang.org)
[![Compose](https://img.shields.io/badge/UI-Jetpack%20Compose-orange.svg)](https://developer.android.com/jetpack/compose)
[![Official Website](https://img.shields.io/badge/Official_Website-algorithm--vault.vercel.app-emerald.svg)](https://algorithm-vault.vercel.app/)

A high-performance, polished, offline-first Android client for **Algorithm Vault**. Explore, search, and study algorithms across Python, C++, and Java with real-time GitHub synchronization, code-syntax viewing, and database caching.

Built in connection and full credit to the official web platform: [algorithm-vault.vercel.app](https://algorithm-vault.vercel.app/).

---

## 🚀 GitHub Release Notes

Copy and paste the section below directly into your **GitHub Release Description** when publishing!

```markdown
## 📱 Algorithm Vault Android Release v1.0.0

An elegant, high-fidelity Material 3 companion app for **Algorithm Vault**, now compiled and available for your Android devices!

### ✨ Key Features in this Release
- **🔄 Dynamic GitHub Sync**: Real-time synchronization of algorithm indexing and metadata directly from the `sakib-12345/AlgorithmVault` repository.
- **📚 Multi-Language Support**: Seamlessly browse and read raw implementation code in **Python**, **C++**, and **Java** with smart path resolutions.
- **⚡ Offline-First Architecture**: Powered by dynamic local database caching (using Android Room) to prevent blank states and keep your study material ready offline.
- **🎨 Modern Material 3 UI**: Polished Dark & Light dynamic color support, gorgeous space-efficient modern card list designs, customized adaptive page icon, and fluid edge-to-edge screens.
- **⚙️ Custom Configurations**: Modify the sync source by changing the Target GitHub Username, Repository, or Branch directly from the settings drawer.

### 🌐 Official Project Credits
This Android application is designed in tight integration with the original web visualizers and code playgrounds. For interactive visualizers and animated runtimes, visit the web app:
👉 **[algorithm-vault.vercel.app](https://algorithm-vault.vercel.app/)**

### 📦 Installation Guide
1. Download the pre-compiled `AlgorithmVault.apk` from the assets below.
2. Open the downloaded APK on your Android device.
3. If prompted, enable "Install from Unknown Sources" for your browser or file manager.
4. Open **Algorithm Vault** and tap the **Sync** button in settings to pull the latest algorithms list!
```

---

## 🎨 Visual Preview & Theme

Our design strategy focuses on **high readability** and a **futuristic Cosmic Slate aesthetic**:
- Generous padding and spacing built over the rigid Material 3 density system.
- Adaptive launcher icons using the custom vector `page_icon`.
- Fully integrated fallback mechanisms to gracefully download Readme files and source code.
- Outlined indicators with high-contrast text tags for algorithmic complex constraints (Time & Space complexities).

---

## 🛠️ Technical Specifications & Stack

- **UI Layer:** 100% Jetpack Compose with type-safe Navigation.
- **Local Persistence:** Android `Room` Database caching `AlgorithmEntity` & `AlgorithmDetailEntity`.
- **JSON Deserialization:** Robust `Moshi JSON` mapping.
- **Networking:** `OkHttp 4` with fast fallback resolution logic.
- **Assets:** High-DPI Vector Drawables (`page_icon.png`).

---

## 📁 Repository Schema Compatibility

The application is programmed to automatically index algorithm structures configured under this JSON template structure:

```json
[
  {
    "id": "binary-search",
    "name": "Binary Search",
    "category": "Searching",
    "difficulty": "Easy",
    "time": "O(log n)",
    "space": "O(1)",
    "tags": ["Search", "Divide and Conquer"],
    "files": {
      "python": "algorithms/binary-search/binary_search.py",
      "cpp": "algorithms/binary-search/binary_search.cpp",
      "java": "algorithms/binary-search/BinarySearch.java"
    }
  }
]
```

It is capable of resolving non-standard paths automatically, prioritizing conventions like `algorithms/{id}/{prefix}.ext` sequentially if specified properties are omitted.

---

## ⚙️ How to Compile / Build APK Locally

You can assemble and output structural APK packages relative to your local development environment:

```bash
# Clean previous builds and compile the APK
gradle assembleDebug --no-configuration-cache
```

The compiled package will automatically copy to the root workspace directory as **`AlgorithmVault.apk`**.

---

*This mobile companion app represents visual engineering with deep structural attention to Material design. Dedicated to @sakib-12345.*
